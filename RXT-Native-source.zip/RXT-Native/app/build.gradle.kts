plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rxt.nativeprofile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rxt.nativeprofile"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-alpha"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    // Supplies rikka.shizuku.ShizukuProvider declared in AndroidManifest.xml.
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
