package com.rxt.nativeprofile

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var profileInfo: TextView
    private var selectedProfile = "Smooth 2"

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        status.text = if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED)
            "Shizuku: izin diberikan" else "Shizuku: izin ditolak"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF10141C.toInt())
        }
        fun heading(text: String, size: Float): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF3F6FA.toInt())
            if (size >= 22) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 12)
        }
        fun action(label: String, callback: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { callback() }
        }

        root.addView(heading("RXT NATIVE", 26f))
        root.addView(heading("Profil grafis non-ANGLE • Shizuku", 14f))
        status = heading("Shizuku: memeriksa…", 14f)
        root.addView(status)
        root.addView(action("Hubungkan / minta izin Shizuku") { requestShizuku() })
        root.addView(action("Periksa driver perangkat") { inspectDevice() })
        root.addView(heading("Pilih profil", 20f))

        val profiles = listOf(
            "Smooth 1" to "Ringan: prioritaskan kestabilan dan beban grafis rendah.",
            "Smooth 2" to "Seimbang: kompromi antara kelancaran dan detail.",
            "Smooth 3" to "Detail lebih terjaga; beban grafis bisa lebih tinggi.",
            "Pixel" to "Preset konsep tampilan piksel. Tidak memaksa resolusi game.",
            "Retro" to "Preset konsep gaya retro. Filter game tidak bisa dipaksakan dari aplikasi luar."
        )
        profiles.forEach { (name, description) ->
            root.addView(action(name) {
                selectedProfile = name
                profileInfo.text = "$name\n$description\n\nStatus: dipilih di aplikasi, belum mengubah renderer atau grafik Free Fire."
            })
        }
        profileInfo = heading("$selectedProfile\nPilih profil untuk melihat keterangannya.", 14f)
        root.addView(profileInfo)
        root.addView(heading("Hasil pemeriksaan", 20f))
        details = heading("Belum diperiksa.", 13f)
        root.addView(details)
        root.addView(heading("Catatan: aplikasi ini tidak mengaktifkan ANGLE, mengganti driver GPU, atau mengubah file Free Fire. Profil baru sebatas preset/diagnostik sampai ada kontrol resmi yang terbukti didukung perangkat.", 12f))

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        updateShizukuStatus()
    }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            status.text = "Shizuku belum aktif. Jalankan layanan Shizuku dulu."
            return
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status.text = "Shizuku: izin sudah diberikan"
        } else {
            Shizuku.requestPermission(1001)
        }
    }

    private fun updateShizukuStatus() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku: belum terhubung"
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "Shizuku: terhubung dan diizinkan"
            else -> "Shizuku: terhubung, izin belum diberikan"
        }
    }

    private fun inspectDevice() {
        if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            details.text = "Hubungkan Shizuku dan berikan izin terlebih dahulu."
            return
        }
        details.text = "Sedang membaca properti grafis…"
        executor.execute {
            val output = try {
                val process = Shizuku.newProcess(
                    arrayOf("sh", "-c", "echo 'GPU vendor:'; getprop ro.hardware.egl; echo 'GPU hardware:'; getprop ro.hardware; echo 'OpenGL ES version code:'; getprop ro.opengles.version; echo 'Vulkan version:'; getprop ro.vulkan.version; echo 'ANGLE package:'; settings get global angle_gl_driver_all_angle"),
                    null,
                    null
                )
                val text = process.inputStream.bufferedReader().use { it.readText() }
                process.waitFor()
                text.ifBlank { "Tidak ada nilai properti yang dikembalikan." }
            } catch (e: Exception) {
                "Gagal membaca properti: ${e.message ?: "kesalahan tidak diketahui"}"
            }
            runOnUiThread { details.text = output }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        executor.shutdownNow()
        super.onDestroy()
    }
}
