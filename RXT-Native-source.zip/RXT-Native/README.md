# RXT Native (prototype source)

Prototype Android Studio project for a Shizuku-connected, non-ANGLE graphics profile helper.

## What it currently does
- Requests Shizuku permission.
- Reads a small set of Android graphics properties using read-only shell commands.
- Shows Smooth 1–3, Pixel, and Retro profile descriptions in the app.

## Important limitations
This prototype does **not** change Free Fire's renderer, GPU driver, shaders, texture filtering, or in-game graphics. An ordinary third-party app cannot force those changes safely on a stock device. The profile buttons are currently UI presets only. Pixel/Retro effects inside Free Fire require game-side support or a supported graphics control; changing Android display settings is not equivalent.

## Build
Open this folder in Android Studio (JDK 17 recommended), allow Gradle sync, then Build > Build APK(s). The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and Shizuku API 13.1.5.

## Test on device
1. Install and start Shizuku.
2. Install the debug APK built from this project.
3. Open RXT Native, grant Shizuku permission, then tap **Periksa driver perangkat**.
4. Share the output so the device's actual EGL/GPU properties can be interpreted before adding any device-specific controls.

No root, bootloader unlock, game-file modification, or ANGLE activation is used.
